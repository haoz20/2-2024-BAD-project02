const mysql = require('mysql2/promise');

exports.handler = async (event) => {
    let connection;
    try {
        
        const body = JSON.parse(event.body);
        const empNo = body.emp_no;
        const firstName = body.first_name; // optional
        const lastName = body.last_name;   // optional
        const deptName = body.dept_name;   // required
        const maxSalary = body.max_salary; // required

        // Validate required fields
        if (!empNo || !deptName || !maxSalary) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'emp_no, dept_name, and max_salary are required.' })
            };
        }

        // Create a connection to the database
        connection = await mysql.createConnection({
            host: process.env.MYSQL_HOST,
            user: process.env.MYSQL_USER,
            password: process.env.MYSQL_PASSWORD,
            database: process.env.MYSQL_DB
        });
        
        // Begin a transaction so that all updates occur together
        await connection.beginTransaction();

        // Update first_name and last_name if provided (optional updates)
        if (firstName) {
            await connection.execute(
                'UPDATE employees SET first_name = ? WHERE emp_no = ?',
                [firstName, empNo]
            );
        }
        if (lastName) {
            await connection.execute(
                'UPDATE employees SET last_name = ? WHERE emp_no = ?',
                [lastName, empNo]
            );
        }
        
        // Retrieve the department number (dept_no) from the departments table using dept_name
        const [deptRows] = await connection.execute(
            'SELECT dept_no FROM departments WHERE dept_name = ?',
            [deptName]
        );
        if (deptRows.length === 0) {
            await connection.rollback();
            return {
                statusCode: 404,
                body: JSON.stringify({ message: `Department '${deptName}' not found.` })
            };
        }
        const deptNo = deptRows[0].dept_no;

        // Update the department assignment in the dept_emp table:
        // For simplicity, delete the current dept_emp row for the employee, then insert a new row.
        // (In a real system, you might keep history or update dates.)
        await connection.execute('DELETE FROM dept_emp WHERE emp_no = ?', [empNo]);
        const today = new Date().toISOString().split('T')[0]; // format: YYYY-MM-DD
        const futureDate = '9999-01-01'; // arbitrarily far-future date
        await connection.execute(
            'INSERT INTO dept_emp (emp_no, dept_no, from_date, to_date) VALUES (?, ?, ?, ?)',
            [empNo, deptNo, today, futureDate]
        );

        // Update max salary in the salaries table.
        // We'll update the row with the latest from_date for this employee.
        const [salaryRows] = await connection.execute(
            'SELECT MAX(from_date) AS latest FROM salaries WHERE emp_no = ?',
            [empNo]
        );
        if (salaryRows.length === 0 || !salaryRows[0].latest) {
            // Optionally, you might choose to insert a new salary record instead.
            await connection.rollback();
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'Salary record not found for this employee.' })
            };
        }
        const latestDate = salaryRows[0].latest;
        await connection.execute(
            'UPDATE salaries SET salary = ? WHERE emp_no = ? AND from_date = ?',
            [maxSalary, empNo, latestDate]
        );

        // Commit the transaction once all updates are done
        await connection.commit();

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Employee updated successfully.' })
        };

    } catch (error) {
        console.error("Error updating employee:", error);
        if (connection) await connection.rollback();
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error updating employee.', error: error.message })
        };
    } finally {
        if (connection) await connection.end();
    }
};
