import json
import pymysql
import os

# Retrieve connection details from environment variables
rds_host = os.environ.get('employee-db.cz6m2u2osh2x.us-east-1.rds.amazonaws.com')
db_username = os.environ.get('admin')
db_password = os.environ.get('bad_project_02')
db_name = os.environ.get('employees')

# The heavy query for fetching the top 10 employees with salary above the average
TOP10_QUERY = """
SELECT e.emp_no, e.first_name, e.last_name, d.dept_name, MAX(s.salary) AS max_salary
FROM employees e
JOIN dept_emp de ON e.emp_no = de.emp_no
JOIN departments d ON de.dept_no = d.dept_no
JOIN (SELECT emp_no, salary FROM salaries WHERE to_date = '9999-01-01') s ON e.emp_no = s.emp_no
WHERE s.salary > (SELECT AVG(salary) FROM salaries)
GROUP BY e.emp_no, e.first_name, e.last_name, d.dept_name
ORDER BY max_salary DESC
LIMIT 10;
"""

def lambda_handler(event, context):
    try:
        # Establish a connection to the RDS MySQL instance
        connection = pymysql.connect(
            host=rds_host,
            user=db_username,
            password=db_password,
            db=db_name,
            cursorclass=pymysql.cursors.DictCursor,  # Return rows as dictionaries
            connect_timeout=5
        )
    except pymysql.MySQLError as e:
        return {
            'statusCode': 500,
            'body': json.dumps("ERROR: Could not connect to MySQL instance: " + str(e))
        }
    
    try:
        with connection.cursor() as cursor:
            cursor.execute(TOP10_QUERY)
            results = cursor.fetchall()  # Fetch all rows as a list of dictionaries
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps("ERROR: Query failed: " + str(e))
        }
    finally:
        connection.close()
    
    return {
        'statusCode': 200,
        'headers': {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"  # Enable CORS if needed
        },
        'body': json.dumps(results)
    }
